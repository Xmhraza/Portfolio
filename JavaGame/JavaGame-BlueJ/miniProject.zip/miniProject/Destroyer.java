public class Destroyer extends evilWarrior{

    int explosionDamage;

    public Destroyer(int level) {
        super(level);
        explosionDamage = 10 * level;
    }

    public evilWarrior damageTaken(Player Player, int choice) {
        super.health = 0;
        return this;
    }

    public Player damageDone(Player player) {
        
            player.health -=  explosionDamage;

            return player;
        }

    public int getExplosionDamage() {
        return explosionDamage;
    }

    public String getName() {
        return "Destroyer";
     }

    
}

public class bossWarrior extends evilWarrior {

    String ability;

    public bossWarrior(int level) {
        super(level);
        ability =  warriorEffect();
    }

    //unique attribute of the boss warrior. Damage dealt based on ability.
    public String warriorEffect() {
        int number = (int)Math.random()*3;

        if (number == 1) {
            return "burn";
        } else if (number == 2) {
            return "paralysis";
        } else {
            return "poison";
        }
    }

    public String getAbility() {
        return ability;
    }

    public int abilityDamage() {
        if (ability == "poison") {
            return 3;
        } else if (ability == "burn") {
            return 2;
        } else return 1;
    }

    public String getName() {
        return "BossWarrior";
     }
    
}

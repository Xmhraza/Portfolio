public class sorrounding {

    String arenaType;
    //super class for creating different sorroundings that will affect the players health
    public sorrounding(String arenaType) {
        this.arenaType = arenaType;
    }

    public int arenaDamage() {
        return 0;
    }

    public String getType() {
        return arenaType;
    }
    
}

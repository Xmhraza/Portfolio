import java.lang.Math;
import java.util.Scanner;

public class Arena {

    //generates an enemy/enemies based on the integer value. The higher the value, the difficult the level
    public static evilWarrior[] levelGenerator(int level) {
   
        if (level == 1) {
            print("Welcome to the game");
            print("The first 3 levels are to help u understand yours and the foes abilities");
            print("Here fight an attack warrior. It attacks more when it's health is low");
            print("Remember that the sorroundings might hurt you, help you or do both");
            evilWarrior warrior1[] = new attackWarrior[1];
            warrior1[0] = new attackWarrior(1);
            return warrior1;
        } else if (level == 2) {
            print("Now you will also face a Destroyer");
            print("They will explode themselves the first chance they get so it is better to defeat them first");
            evilWarrior warrior1[] = new evilWarrior[2];
            warrior1[0] = new attackWarrior(1);
            warrior1[1] = new Destroyer(1);
            return warrior1;
        } else if (level == 3) {
            print("Lastly there is a defence warrior");
            print("These warriors have extra shield to protect them");
            print("Not only that. They can use their shield to protect a targeted Destroyer");
            print("only your special attack is immune to the shielding system");
            evilWarrior warrior1[] = new evilWarrior[3];
            warrior1[0] = new attackWarrior(1);
            warrior1[1] = new Destroyer(1);
            warrior1[2] = new defenceWarrior(1);
            return warrior1;
        } else{
            evilWarrior warriorTotal[] = new evilWarrior[level];
            for (int i = 0; i < level; i++) {
                int count = (int)(Math.random() * 3 + 1);
                if (count == 1) {
                    warriorTotal[i] = new attackWarrior(level/2);
                } else if (count == 2) {
                    warriorTotal[i] = new Destroyer(level/2);
                } else {
                    warriorTotal[i] = new defenceWarrior(level/2);
                }

            }
            return warriorTotal;

    }
    
}
    //creating enemy for the boss level
    public static evilWarrior[] bossLevel() {
        print("This is your final battle");
            print("The bossWarrior is the mightiest of warriors");
            print("He will also have an ability that will damage you each round so play safe");
             evilWarrior bossWarrior[] = new bossWarrior[1];
             bossWarrior[0] = new bossWarrior(5);
           return bossWarrior;
       
    }
    
    public static void credits(boolean playerPosition) {
        if (playerPosition == false) {
            print("Congratulations!!! You have won the game");
        } else {
            print("Unlucky.... Try again. This time try to buy different items and use a stronger strategy. Good Luck");
        }
        
        int tryAgain = inputInt("If you want to play the game again, Press 1 else press any other number");
        if (tryAgain == 1) {
            mainProgram.level1();
        }
    }
    
   

    public static void print(String message) {
        System.out.println(message);
    }
    
     public static int inputInt(String message) {
        Scanner scanner = new Scanner(System.in);
        System.out.println(message);
        int answer = scanner.nextInt();
        return answer;
    }
    
}

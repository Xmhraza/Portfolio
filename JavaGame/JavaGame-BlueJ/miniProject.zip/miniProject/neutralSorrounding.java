import java.lang.Math;

public class neutralSorrounding extends sorrounding{
    public neutralSorrounding() {
        super("neutral");
    }

    public int arenaAffect() {
        if ( Math.random() * 2 == 1) {
            return 1;
        } else {
            return -1;
        }
    }
}

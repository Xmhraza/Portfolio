import java.util.Scanner;

public class shop {
    
    //player can increase a specific stat when shop is called
    public static Player Shop(Player player) {

        int ModificationChoice;
        boolean buyItems;
        buyItems = false;
        Scanner input = new Scanner(System.in);

        print("Welcome to the shop. It currently has : ");
        print("1. Health: increases health by 5");
        print("2. Power: increases attack by 5 ");
        print("3. Armour: increases defense by 5 ");
        print("4. Ability Upgrade: increases special by 5");

        print("");
        print("Press the number representing the upgrade.");
        print("PLease make a wise choice. Too low attack and mobs will not be affected.");
        print( "Too low defense and mobs will finish you in an instant");

        

        do {
           
           ModificationChoice = input.nextInt();
           if (ModificationChoice == 1 || ModificationChoice == 2 || ModificationChoice == 3 || ModificationChoice == 4 ) {
              buyItems = true;
           } else {
               buyItems = false;
               print("Please upgrade or you will not be able to fight");
           }

        } while (buyItems == false);

        if (ModificationChoice == 1) {
            System.out.println("Congratulations!!! You have upgraded armour !!!");
           player.health += 5;
        } else if (ModificationChoice == 2) {
            System.out.println("Congratulations!!! " + player.name + " has more Power now!!!");
           player.attackDamage += 3;
        } else if (ModificationChoice == 3) {
            System.out.println("Congratulations!!! " + player.name + " has shield now!!!");
            player.defence += 3;
        } else if (ModificationChoice == 4) {
            System.out.println("Congratulations!!! " + player.name + "'s special ability has been upgraded!!!");
            player.specialAttack += 10;
        } else {
            print("No upgrades have been made.");
        }

        print("");
        clearScreen();

        return player;


    }
    
     private static void clearScreen()
   {
      System.out.print('\u000C');
   }

   
    public static void print(String message) {
        System.out.println(message);
    }
    
}

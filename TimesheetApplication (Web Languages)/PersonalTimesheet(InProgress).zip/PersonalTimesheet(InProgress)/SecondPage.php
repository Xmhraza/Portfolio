<?php 

$servername = "localhost";
$username = "test";
$password = "Leonidas";
$dbname = "test";
$portNo = 3307;
$socketName = "D:/Xampp/mysql/mysql.sock";

  
 // Create connection
 $conn = mysqli_connect($servername,
     $username, $password, $dbname, $portNo, $socketName);

//$query2 = mysqli_query($conn, "SELECT * from testing WHERE week(StartDate)=week(now())-1 ORDER BY StartDate");
//$query = mysqli_query($conn, "SELECT * FROM testing WHERE yearweek(DATE(StartDate), 1) = yearweek(curdate(), 1) ORDER BY StartDate");
//$query3 = mysqli_query($conn, "SELECT * from testing ORDER BY StartDate ");


if (isset($_COOKIE['varname'])) {
    if ($_COOKIE['varname'] == 1) {
        $query = mysqli_query($conn, "SELECT * from testing WHERE week(StartDate)=week(now())-1 ORDER BY StartDate");
    } elseif($_COOKIE['varname'] == 0) {
        $query = mysqli_query($conn, "SELECT * FROM testing WHERE yearweek(DATE(StartDate), 1) = yearweek(curdate(), 1) ORDER BY StartDate");
    } elseif($_COOKIE['varname'] == 2) {
        $query = mysqli_query($conn, "SELECT * from testing ORDER BY StartDate ");
    } else {
        $query =  mysqli_query($conn, "SELECT * from testing WHERE StartDate LIKE '%{$_COOKIE['Date']}%' ");
    }
} elseif (!isset($_COOKIE['varname'])) {
    $_COOKIE['varname'] = 0;
    $query = mysqli_query($conn, "SELECT * FROM testing WHERE yearweek(DATE(StartDate), 1) = yearweek(curdate(), 1) ORDER BY StartDate");
}



    
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">



    <script>
        function TimeSubtraction(dt2, dt1) {
        var diff =(dt2 - dt1);
        diff /= 60;
        return Math.abs(Math.round(diff));
        }
    </script>

<?php include "Test.html" ?>
<link href="test.css" rel="stylesheet">
<body>
<br>
<br>
<?php 
 
    //ORDER BY StartDate 
    //
    //"SELECT * FROM testing WHERE yearweek(DATE(StartDate), 1) = yearweek(curdate(), 1) ORDER BY StartDate"

$NewArray = array();
$date = '2007-05-14';
$datetime = strtotime("$date 00:00:00");
$record = array();
while($row = mysqli_fetch_assoc($query)){
    $record[] = $row;
}
?>
<div class="container text-center color">
<div class="row">
  <div class="btn-group col-sm-5 " role="group" aria-label="First group">
    <button class="btn btn-primary buttonColor" type="button" onclick="ChangingQueryToLastWeek()">Last Week</button>
    <button class="btn btn-primary buttonColor" type="button" onclick="ChangingQueryToCurrentWeek()">Current Week</button>
    <button class="btn btn-primary buttonColor" type="button" onclick="ChangingQueryToAll()" >All Records</button>
  </div>
  <div class="col-sm-3 offset-2" role="group" aria-label="Second group">
    <input type='date' name="Start_Date" class="form-control" id="Date"/>
    
  </div>
  <div class="col-sm-2">
     <button class=" btn btn-primary buttonColor" type="button" onclick="ChangingQueryToDate()">Date Search</button>
  </div>

</div>
    
    <br>
    <br>

    <div class="row border SecondPageHeader">
        <div class="col border">Start Date</div>
        <div class="col border">Start Time</div>
        <div class="col border">End Time</div>
        <div class="col border">Email</div>
        <div class="col border">Selection</div>
        <div class="col border">Hours Worked</div>
    </div>


<?php
foreach ($record as $record) { ?>
  <div class="row border">
  <div class="col-sm-2 border"><?php echo $record['StartDate'];?></div>
  <div class="col-sm-2 border"><?php echo $record['StartTime'];?></div>
  <div class="col-sm-2 border"><?php echo $record['EndTime'];?></div>
  <div class="col-sm-2 overflow-hidden border"><?php echo $record['Email'];?></div>
  <div class="col-sm-2 border"><?php echo $record['Selection'];?></div>

 
  <?php 
  $a = new DateTime($record['StartTime']);
  $b = new DateTime($record['EndTime']);
  $interval = $a->diff($b);
  array_push($NewArray, $interval->format("%H:%I"));
  ?>
  <div class="col-sm-2 border"><?php echo $interval->format("%H:%I"); ?></div>
  </div>
  <?php } ?>
  <br><br>
  <?php
$sum = 0;
foreach($NewArray as $time) {
    $sum += strtotime("$date $time") - $datetime;
    $minutes = $sum / 60;
    $quotient = intval($minutes / 60);
    $minutesLeft = $minutes % 60;
}
  if (isset($quotient) && isset($minutesLeft)) {
    echo "total number of Hours : ",  $quotient, " \ntotal number of minutes : ", $minutesLeft; 
  }?> 
  
<br>


</div>    

</body>

<script>
    document.addEventListener("DOMContentLoaded", SettingColor()); 
       function SettingColor(){
        const linkColor = document.querySelectorAll('.nav_link')
        const linkSpecific = document.getElementById('SecondPage')

        
        if(linkColor && linkSpecific){
           linkColor.forEach(l=> l.classList.remove('active'))
           linkSpecific.classList.add('active')
       }
    } 

    function ChangingQueryToLastWeek(){
        document.cookie = "varname = 1";
        console.log("Checking2");
        location.reload(); 
    }

    function ChangingQueryToCurrentWeek(){
        document.cookie = "varname = 0";
        console.log("Checking");
        location.reload(); 
    }

    function ChangingQueryToAll(){
        document.cookie = "varname = 2";
        console.log("Checking");
        location.reload(); 
    }

    function ChangingQueryToDate(){
        document.cookie = "varname = 3";
        document.cookie = "Date = " + document.getElementById("Date").value;
        console.log("Checking");
        location.reload(); 
    }

</script>


<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">

<?php include "Test.html" ?>
<link href="test.css" rel="stylesheet">

<body>

<br>

<form action="Connection.php" method="post">

<div class="container margin">
    <div class="row">
    <div class="col-md-4 offset-md-4 color">
    <div class="row mb-4">
    <div class="col">
      <div class="form-outline">
         <label class="form-label" for="StartDate">Start Date</label>
         <input type='date' name="Start_Date" class="form-control" id="StartDate"/>
      </div>
    </div>
    <div class="col">
      <div class="form-outline">
         <label class="form-label" for="StartTime">Start Time</label>
         <input type='time' name="Start_Time" class="form-control" id="StartTime"/>
      </div>
    </div>
  </div>

  <div class="row mb-4">
    <div class="col">
      <div class="form-outline">
         <label class="form-label" for="EndDate">End Date</label>
         <input type='date' name="End_Date" class="form-control" id="EndDate"/>
      </div>
    </div>
    <div class="col">
      <div class="form-outline">
         <label class="form-label" for="EndTime">End Time</label>
         <input type='time' name="End_Time" class="form-control" id="EndTime"/>
      </div>
    </div>
  </div>
  <!-- form-outline -->
  <div class="form-outline mb-4">
    <label class="form-label" for="form3Example3">Email address</label>
    <input type="email" name="email" id="form3Example3" class="form-control" />
    
  </div>

  <!-- Password input -->
  <div class="form-outline mb-4">
    <label class="form-label" for="form3Example4">Password</label>
    <input type="password" name="password" id="form3Example4" class="form-control" />
    
  </div>
  
  <label class="form-label">Select Work Type</label>
  <select class="form-select" name="selection" aria-label="Default select example">
  <option selected>Open this select menu</option>
  <option value="1">One</option>
  <option value="2">Two</option>
  <option value="3">Three</option>
  </select>

  
  <br>

  <div class="row mb-4 text-center" >
    <div class="col">
      <div class="form-outline ">
        <input class="btn btn-primary buttonColor" type="submit" value="Submit">
      </div>
    </div>
    <div class="col">
      <div class="form-outline">
      <input class="btn btn-primary buttonColor" type="reset" value="Reset">
      </div>
    </div>
  </div>

 </div>

 </div>

</div>

</form>





</body>

<script>
    document.addEventListener("DOMContentLoaded", SettingColor()); 

       function SettingColor(){
        const linkColor = document.querySelectorAll('.nav_link')
        const linkSpecific = document.getElementById('FirstPage')

        
        if(linkColor && linkSpecific){
           linkColor.forEach(l=> l.classList.remove('active'))
           linkSpecific.classList.add('active')
       }
    } 
</script>
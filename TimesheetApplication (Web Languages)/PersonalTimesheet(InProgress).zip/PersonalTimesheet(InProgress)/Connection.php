<?php
 
$servername = "localhost";
$username = "test";
$password = "Leonidas";
$dbname = "test";
$portNo = 3307;
$socketName = "D:/Xampp/mysql/mysql.sock";
 
// Create connection
$conn = mysqli_connect($servername,
    $username, $password, $dbname, $portNo, $socketName);
 
// Check connection
if ($conn->connect_error) {
    die("Connection failed: "
        . $conn->connect_error);
}

$StartTime =  $_REQUEST['Start_Time'];
$EndTime = $_REQUEST['End_Time'];
$StartDate =  $_REQUEST['Start_Date'];
$EndDate = $_REQUEST['End_Date'];
$Email = $_REQUEST['email'];
$Password = $_REQUEST['password'];
$Selection = $_REQUEST['selection'];

$sql = "INSERT INTO testing  VALUES (DEFAULT, '$StartDate',
            '$EndDate','$StartTime','$EndTime','$Email','$Password','$Selection')";
         
        if(mysqli_query($conn, $sql)){
            echo "<h3>data stored in a database successfully."
                . " Please browse your localhost php my admin"
                . " to view the updated data</h3>";
 
            echo nl2br("\n$StartDate\n $EndDate\n "
                . "$StartTime\n $EndTime\n $Email\n $Password\n $Selection\n");
        } else{
            echo "ERROR: Hush! Sorry $sql. "
                . mysqli_error($conn);
        }
         
        // Close connection
        mysqli_close($conn);
?>
 

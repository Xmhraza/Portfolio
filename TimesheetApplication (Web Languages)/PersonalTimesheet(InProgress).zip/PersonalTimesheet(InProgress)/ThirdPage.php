<?php 

$servername = "localhost";
$username = "test";
$password = "Leonidas";
$dbname = "test";
$portNo = 3307;
$socketName = "D:/Xampp/mysql/mysql.sock";
  
 // Create connection
 $conn = mysqli_connect($servername,
     $username, $password, $dbname, $portNo, $socketName);

//$query2 = mysqli_query($conn, "SELECT * from testing WHERE week(StartDate)=week(now())-1 ORDER BY StartDate");
//$query = mysqli_query($conn, "SELECT * FROM testing WHERE yearweek(DATE(StartDate), 1) = yearweek(curdate(), 1) ORDER BY StartDate");
//$query3 = mysqli_query($conn, "SELECT * from testing ORDER BY StartDate ");



$query = mysqli_query($conn, "SELECT * from testing WHERE week(StartDate)=week(now())-1 OR yearweek(DATE(StartDate), 1) = yearweek(curdate(), 1) ORDER BY StartDate");

$monthlyQuery = mysqli_query($conn, "SELECT * FROM testing WHERE MONTH('StartDate') = MONTH(CURRENT_DATE()) AND YEAR('StartDate') = YEAR(CURRENT_DATE())");

    
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">

<script
src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/2.9.4/Chart.js">
</script>


<?php include "Test.html" ?>
<?php 
 
    //ORDER BY StartDate 
    //
    //"SELECT * FROM testing WHERE yearweek(DATE(StartDate), 1) = yearweek(curdate(), 1) ORDER BY StartDate"

$ArrayForLineGraph = array();
$ArrayForLineGraphX[0] = "Monday";
$ArrayForLineGraphX[1] = "Tuesday";
$ArrayForLineGraphX[2] = "Wednesday";
$ArrayForLineGraphX[3] = "Thursday";
$ArrayForLineGraphX[4] = "Friday";

$ArrayForLineGraph[0] = 0;
$ArrayForLineGraph[1] = 0;
$ArrayForLineGraph[2] = 0;
$ArrayForLineGraph[3] = 0;
$ArrayForLineGraph[4] = 0;

$ArrayForCurrentLineGraph[0] = 0;
$ArrayForCurrentLineGraph[1] = 0;
$ArrayForCurrentLineGraph[2] = 0;
$ArrayForCurrentLineGraph[3] = 0;
$ArrayForCurrentLineGraph[4] = 0;

$ArrayForCurrentBarGraph[0] = 0;
$ArrayForCurrentBarGraph[1] = 0;
$ArrayForCurrentBarGraph[2] = 0;


$date = '2007-05-14';
$datetime = strtotime("$date 00:00:00");
$record = array();
while($row = mysqli_fetch_assoc($query)){
    $record[] = $row;
}
?>

<?php
$sum = 0;
foreach($record as $record) {

    if (date('D', strtotime($record['StartDate'])) == "Mon") {
        $a = new DateTime($record['StartTime']);
        $b = new DateTime($record['EndTime']);
        $interval = $a->diff($b);
        $NewInterval = $interval->format("%H:%I");
        $sum = strtotime("$date $NewInterval") - $datetime;
        $minutes = $sum / 60;
        $quotient = intval($minutes / 60);
        if (date('W') == date('W', strtotime($record['StartDate']))) {
            $ArrayForCurrentLineGraph[0] += $quotient;  
        } else {
            $ArrayForLineGraph[0] += $quotient; 
        }
    } elseif (date('D', strtotime($record['StartDate'])) == "Tue") {
        $a = new DateTime($record['StartTime']);
        $b = new DateTime($record['EndTime']);
        $interval = $a->diff($b);
        $NewInterval = $interval->format("%H:%I");
        $sum = strtotime("$date $NewInterval") - $datetime;
        $minutes = $sum / 60;
        $quotient = intval($minutes / 60);
        if (date('W') == date('W', strtotime($record['StartDate']))) {
            $ArrayForCurrentLineGraph[1] += $quotient;  
        } else {
            $ArrayForLineGraph[1] += $quotient; 
        }   
    } elseif (date('D', strtotime($record['StartDate'])) == "Wed") {
        $a = new DateTime($record['StartTime']);
        $b = new DateTime($record['EndTime']);
        $interval = $a->diff($b);
        $NewInterval = $interval->format("%H:%I");
        $sum = strtotime("$date $NewInterval") - $datetime;
        $minutes = $sum / 60;
        $quotient = intval($minutes / 60);
        if (date('W') == date('W', strtotime($record['StartDate']))) {
            $ArrayForCurrentLineGraph[2] += $quotient;  
        } else {
            $ArrayForLineGraph[2] += $quotient; 
        }   
    } elseif (date('D', strtotime($record['StartDate'])) == "Thu") {
        $a = new DateTime($record['StartTime']);
        $b = new DateTime($record['EndTime']);
        $interval = $a->diff($b);
        $NewInterval = $interval->format("%H:%I");
        $sum = strtotime("$date $NewInterval") - $datetime;
        $minutes = $sum / 60;
        $quotient = intval($minutes / 60);
        if (date('W') == date('W', strtotime($record['StartDate']))) {
            $ArrayForCurrentLineGraph[3] += $quotient;  
        } else {
            $ArrayForLineGraph[3] += $quotient; 
        }
    } elseif (date('D', strtotime($record['StartDate'])) == "Fri") {
        $a = new DateTime($record['StartTime']);
        $b = new DateTime($record['EndTime']);
        $interval = $a->diff($b);
        $NewInterval = $interval->format("%H:%I");
        $sum = strtotime("$date $NewInterval") - $datetime;
        $minutes = $sum / 60;
        $quotient = intval($minutes / 60);
        if (date('W') == date('W', strtotime($record['StartDate']))) {
            $ArrayForCurrentLineGraph[4] += $quotient;  
        } else {
            $ArrayForLineGraph[4] += $quotient; 
        }   
    } 
    

    if ($record['Selection'] == "2") {
        $ArrayForCurrentBarGraph[1] += 1;
    } elseif ($record['Selection'] == "1") {
        $ArrayForCurrentBarGraph[0] += 1;
    } else {
        $ArrayForCurrentBarGraph[2] += 1;
    };
    
}


?>

<body>
        
   <canvas id="myChart" width="800" height="350">

   </canvas>

   <canvas id="barChart" width="800" height="350" style="display:none;">

   </canvas>

   <button class="btn btn-primary buttonColor" type="button" onclick="ChangingGraphs()">Hide Graph</button>

<script>

    var graph;
   function getData() {
        var arry = <?php echo json_encode($ArrayForLineGraph);?>;
        for (let i = 0; i < 4; i++) {
          arry[i+1] += arry[i]
        }
        
        return arry;
    }

    function getCurrentData() {
        var arry = <?php echo json_encode($ArrayForCurrentLineGraph);?>;
        for (let i = 0; i < 4; i++) {
          arry[i+1] += arry[i]
        }
        
        return arry;
    }

    function getSelection() {
        var arry = <?php echo json_encode($ArrayForCurrentBarGraph);?>;
        console.log(arry);
        return arry
    }

   document.addEventListener("DOMContentLoaded", ChartCreate()); 
   
    function ChartCreate() {

    

    var xValues = ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday"];
   graph =  new Chart("myChart", {
   type: "line",
   data: {
    labels: xValues,
    datasets: [{
      label: "Previous Week Hours",
      borderColor: "rgba(0,0,0,0.1)",
      data: getData(),
      fill: false
    }, {
      label: "Current Week Hours",
      borderColor: "rgba(12,13,14,15.1)",
      data: getCurrentData(),
      fill: false
    }]
    }
  }); 

   const labels =  [1, 2, 3];

   new Chart("barChart", {
   type: "bar",
   data: {
    labels: labels,
  datasets: [{
    label: 'My First Dataset',
    data: getSelection(),
    backgroundColor: [
      'rgba(255, 99, 132, 0.2)',
      'rgba(255, 159, 64, 0.2)',
      'rgba(255, 205, 86, 0.2)'
    ],
    borderColor: [
      'rgb(255, 99, 132)',
      'rgb(255, 159, 64)',
      'rgb(255, 205, 86)'
    ],
    borderWidth: 1
  }]
    }
  }); 
  
}
</script>

</body>

<script>
    document.addEventListener("DOMContentLoaded", SettingColor()); 

       function SettingColor(){
        const linkColor = document.querySelectorAll('.nav_link')
        const linkSpecific = document.getElementById('ThirdPage')

        
        if(linkColor && linkSpecific){
           linkColor.forEach(l=> l.classList.remove('active'))
           linkSpecific.classList.add('active')
       }
    } 

    function ChangingGraphs() {
        const OldChart = document.getElementById('myChart')
        const NewChart = document.getElementById('barChart')
        if (OldChart.style.display == "none") {
            OldChart.style.display = "block";
            NewChart.style.display = "none";
            OldChart.classList.add("in");
            NewChart.classList.add("out");
        } else {
            OldChart.style.display = "none";
            NewChart.style.display = "block";
            OldChart.classList.add("out");
            NewChart.classList.add("in");
        }
        
    }

    
</script>
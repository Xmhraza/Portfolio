public class sorrounding {

    String arenaType;

    public sorrounding(String arenaType) {
        this.arenaType = arenaType;
    }

    public int arenaDamage() {
        return 0;
    }

    public String getType() {
        return arenaType;
    }
    
}

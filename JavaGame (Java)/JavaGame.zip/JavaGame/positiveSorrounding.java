public class positiveSorrounding extends sorrounding{

    public positiveSorrounding() {
        super("positive");
    }

    public int arenaAffect() {
        return +2;
    }
    
}

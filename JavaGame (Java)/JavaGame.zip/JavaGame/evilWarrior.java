public class evilWarrior extends entity {


    public evilWarrior(int level) {
        super(10 * level, 3 * level, 3 * level);
    }

    public evilWarrior damageTaken(Player Player, int choice) {
       if (choice == 1) {
           this.health -= (int)(Player.getSAttack() / this.getDefence());
       } else {
        this.health -= (int)(Player.getAttackDamage() / this.getDefence());
       }
        
        return this;
    }

    public Player damageDone(Player player) {
        
            player.health -= (int)(this.getAttackDamage() / player.getDefence());

        return player;

    }
    
    public int getSpecialAttack() {
        return specialAttack;
    }

    public String getAbility() {
        return "";
    }

    public int abilityDamage() {
       return 1;
    }

    

    public String getName() {
        return "";
     }
}

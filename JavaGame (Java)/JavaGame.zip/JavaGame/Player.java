import java.util.Scanner;

public class Player extends entity{
    
    String name;
    int age;
    int specialAttack;
    
    public Player() {
        super(100, 50, 3);

        name = inputString("Please input the name of your character");
        age = inputInt("Please tell us your age");
        specialAttack = 10;

    }

    public void getName() {
        super.getName(name);
    }


    public int getSAttack() {
        return specialAttack;
    }

    public static String inputString(String message) {
        Scanner scanner = new Scanner(System.in);
        System.out.println(message);
        String answer = scanner.nextLine();
        return answer;
    }

    public static int inputInt(String message) {
        Scanner scanner = new Scanner(System.in);
        System.out.println(message);
        int answer = scanner.nextInt();
        return answer;
    }



    

    
}


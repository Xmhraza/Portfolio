import java.lang.Math;

public class defenceWarrior extends evilWarrior {

    int shield;

    public defenceWarrior(int level) {
        super(level);
        shield = ((int)Math.random()+1) * level;
    }

    public evilWarrior damageTaken(Player Player, int choice) {
        if (this.shield > 0) {
            this.shield -= Player.getAttackDamage();
            System.out.println("The shield absorbed the attack");
            return this;
        } else  if (choice == 1) {
            this.health -= (int)(Player.getSAttack() / this.getDefence());
        } else {
         this.health -= (int)(Player.getAttackDamage() / this.getDefence());
        }

        return this;
    }

    public String getName() {
       return "DefenceWarrior";
    }

}
import java.util.Scanner;
import java.lang.Math;

public class mainProgram {

    public static void main(String[] a) {
        level1();

    }

    public static void level1() {

        Player newPlayer = new Player();
        int level = 7;
        int i = 0;
        boolean playerLost = false;
        boolean bossLost = false;

        //The main game. One method as all the code is specifically about the battle. Only the boss battle has a seperate method
        while (i < level && playerLost == false) {

            //player is allowed to buy an item once per level
            newPlayer = shop.Shop(newPlayer);
            boolean shieldForDestroyer = false;
           //generates a new level using the counter i
            evilWarrior newWarrior[] = new evilWarrior[i+1];
            newWarrior = Arena.levelGenerator(i+1);

           if (i == 6) {
                evilWarrior bossWarrior[] = new evilWarrior[1];
                bossWarrior = Arena.bossLevel();
                bossBattle(bossWarrior, newPlayer);
            }
            
            
            //creates a sorrounding that damages/heals player
           sorrounding currentSorrounding = new sorrounding("");
           currentSorrounding = getSorrounding(currentSorrounding);
           
           

            //provides a shield for destroyer. The shield is active when there is a defenceWarrior present
            if (i < 6) {
                for (int q = 0; q < i+1; q++) {
                    if (newWarrior[q] instanceof defenceWarrior) {
                        shieldForDestroyer = true;
                    }
                }
            }
            

            int mobKilled = 0;
            String listNum[] = new String[i+1];
            for (int y = 0; y < i+1; y++) {
                listNum[y] = y+"";
            }
            
            int PlayerattackChoice=-1;
            boolean specialAttackUsed = false;
            
    
            int playerHealth = (int)newPlayer.getHealth();
            boolean validationCheck = false;
           
               //battle per every wave
                while (mobKilled < i+1 && playerLost == false && i<6) {
                    
                    //outputting the name of every mob present with a unique number
                    for (int y = 0; y < i+1; y++) {
                        print(listNum[y]+" "+newWarrior[y].getName());
                    }

                    validationCheck = false;
                    //Code to calculate every possible damage done by the player
                    //validating to see if the number inputted is within the list numbers.
                    while (validationCheck == false) {
                        PlayerattackChoice = inputInt("who do u want to attack ? Press 10 for your special attack");
                        if (PlayerattackChoice > i || PlayerattackChoice < 0) {
                            if (PlayerattackChoice != 10) {
                                print("Wrong choice. Please try again");
                            } else if (specialAttackUsed != true){
                                validationCheck = true;
                            }
                        } else if (listNum[PlayerattackChoice].equals("[dead]")) {
                            print("The entity is already dead");
                        } else {
                            validationCheck = true;
                        }

                    }
                    //Use of your special attack. Can only be used once
                    if (specialAttackUsed == false && PlayerattackChoice == 10) {
                        PlayerattackChoice = inputInt("who do you want the special attack to be on ?");
                        if (specialAttackUsed == false && PlayerattackChoice > i || PlayerattackChoice < 0) {
                                newWarrior[PlayerattackChoice] = newWarrior[PlayerattackChoice].damageTaken(newPlayer, 1);
                                print(newPlayer.getName() + " uses his special attacks on the " + newWarrior[PlayerattackChoice].getName());
                                specialAttackUsed = true;
                        }
                            
                    } else {
                    //To check whether the target is a destroyer so the shield can be given to it if there is a defence warrior present
                            if (newWarrior[PlayerattackChoice] instanceof Destroyer) {
                            if (shieldForDestroyer == true) {
                                 print("The shield of the defenceWarrior has protected the Destroyer");
                                 shieldForDestroyer = false;
                            } else {
                                newWarrior[PlayerattackChoice] = newWarrior[PlayerattackChoice].damageTaken(newPlayer, 0);
                                print(newPlayer.getName() +" attacks the " + newWarrior[PlayerattackChoice].getName());
                            }
                        } else {
                             newWarrior[PlayerattackChoice] = newWarrior[PlayerattackChoice].damageTaken(newPlayer, 0);
                             print(newPlayer.getName() +" attacks the " + newWarrior[PlayerattackChoice].getName());
                        }
                            
                    }
                         
                        if (newWarrior[PlayerattackChoice].health <= 0) {
                            print("The " + newWarrior[PlayerattackChoice].getName() +" has fallen");
                            mobKilled += 1;
                            listNum[PlayerattackChoice]="[dead]";

                        } else {
                            System.out.println(newWarrior[PlayerattackChoice].getName()+" health remaining : " + newWarrior[PlayerattackChoice].getHealth());
                        }

                    //code to implement every type of damage done to the player
                    for (int x = 0; x < listNum.length; x++) {
                        if (listNum[x].equals("[dead]")) {
                            System.out.print("");
                        } else if (newWarrior[x] instanceof Destroyer) {
                            newPlayer = newWarrior[x].damageDone(newPlayer);
                            print("The Destroyer at position " +listNum[x]+ " exploded!!!");
                            if (newPlayer.health <= 0) {
                                print("The Destroyer explosion defeated " + newPlayer.getName());
                                playerLost = true;
                            } else {
                                print(newPlayer.getName() + "'s health remaining : " + newPlayer.getHealth());
                            }
                            listNum[x] = "[dead]";
                            mobKilled += 1;
                        } else {
                            newPlayer = newWarrior[x].damageDone(newPlayer);
                            print(newWarrior[x].getName()+" at position " + listNum[x] + " attacks " + newPlayer.getName());
                            if (newPlayer.health <= 0) {
                                print("The player has fallen");
                                playerLost = true;
                            } else {
                                print(newPlayer.getName() + "'s health remaining : " + newPlayer.getHealth());
                            }
                        }

                    }
                    //implementing the effect of the sorroundings created by the sorrounding class
                    print("The current sorroundings are: " + currentSorrounding.getType());
                    playerHealth += currentSorrounding.arenaDamage();

            }

            clearScreen();
            newPlayer.health = playerHealth;
            i += 1;
        }
        
        Arena.credits(playerLost);

     }
     
     //code designed specifically for the boss fight
     public static void bossBattle(evilWarrior newWarrior[], Player newPlayer) {
          boolean bossLost = false;
          boolean playerLost = false;
          int specialChoice;
          boolean specialAttackUsed = false;
         
         while (bossLost == false && playerLost == false){
                specialChoice = inputInt("Do you want to use your special Attack ? Press 1 to confirm. Any other number to reject");
                if (specialAttackUsed == false && specialChoice==1) {
                        newWarrior[0] = newWarrior[0].damageTaken(newPlayer, 1);
                        print(newPlayer.getName() +" uses his special attacks on the " + newWarrior[0].getName());
                        specialAttackUsed = true;
                } else {
                    newWarrior[0] = newWarrior[0].damageTaken(newPlayer, 0);
                    print(newPlayer.getName() +" attacks the " + newWarrior[0].getName());
                }

                if (newWarrior[0].health <= 0) {
                    print("The " + newWarrior[0].getName() +" has fallen");
                    bossLost = true;
                } else {
                    System.out.println(newWarrior[0].getName()+" health remaining : " + newWarrior[0].getHealth());
                }

                

                if (bossLost == false) {
                    print("The bossWarrior's ability "+newWarrior[0].getAbility() + " has damaged your health: " + newWarrior[0].abilityDamage());
                    newPlayer.health -=  newWarrior[0].abilityDamage();
    
    
                    newPlayer = newWarrior[0].damageDone(newPlayer);
                    print(newWarrior[0].getName()+ " attacks the " + newPlayer.getName());
                    if (newPlayer.health <= 0) {
                        print(newPlayer.getName() +" has fallen");
                        playerLost = true;
                    } else {
                        print(newPlayer.getName() + "'s health remaining : " + newPlayer.getHealth());
                    }
    
                }
                

            }
        }
     
        //creating a sorrounding using a random number
     public static sorrounding getSorrounding(sorrounding currentSorrounding) {
         int randomNo = (int)(Math.random() * 3); 
         
         if (randomNo == 2) {
                currentSorrounding = new positiveSorrounding();
            } else if (randomNo == 1) {
                currentSorrounding = new neutralSorrounding();
            } else {
                currentSorrounding = new negativeSorrounding();
            }
         return currentSorrounding;
         
        }
        
        private static void clearScreen()
   {
      System.out.print('\u000C');
   }


            


    public static void print(String message) {
        System.out.println("");
        System.out.println(message);
    }

    public static String inputString(String message) {
        Scanner scanner = new Scanner(System.in);
        System.out.println(message);
        String answer = scanner.nextLine();
        return answer;
    }

    public static int inputInt(String message) {
        Scanner scanner = new Scanner(System.in);
        System.out.println(message);
        int answer = scanner.nextInt();
        return answer;
    }
    
}

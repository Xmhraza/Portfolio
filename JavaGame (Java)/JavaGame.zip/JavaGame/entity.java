

public class entity {

    float health;
    float attackDamage;
    float defence;
    int specialAttack;
    int movementSpeed;
    
    public entity(float health, float attackDamage, float defence) {
          this.health = health;
          this.attackDamage = attackDamage;
          this.defence = defence;
    }

    public float getHealth() {
        return health;
    }

    public float getAttackDamage() {
        return attackDamage;
    }

    public float getDefence() {
        return defence;
    } 

    public String getName(String name) {
        return name;
    }

    public entity damageDone(entity evil) {
        evil.health -= (int)this.attackDamage - evil.defence;
        return evil;
    }

    public entity damageTaken(entity evil) {
        this.health += (int)this.defence - evil.attackDamage;
        return this; 
    }



    

    
}

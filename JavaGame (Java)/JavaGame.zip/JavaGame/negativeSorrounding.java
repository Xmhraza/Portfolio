public class negativeSorrounding extends sorrounding {
    
        public negativeSorrounding() {
            super("negative");
        }
    
        public int arenaAffect() {
            return -2;
        }
        

}

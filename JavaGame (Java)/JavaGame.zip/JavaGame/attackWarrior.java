import java.lang.Math;

public class attackWarrior extends evilWarrior {

    
    int specialAttack;

    public attackWarrior(int level) {
        super(level);
        specialAttack = 5 * level;
        

    }

    public Player damageDone(Player player) {
        if (this.health <= 5) {
            player.health -= (int)(this.specialAttack / player.getDefence());
        } else {
            player.health -= (int)(this.getAttackDamage() / player.getDefence());
        }

        return player;

    }

    

    public String getName() {
        return "AttackWarrior";
     }
    
}

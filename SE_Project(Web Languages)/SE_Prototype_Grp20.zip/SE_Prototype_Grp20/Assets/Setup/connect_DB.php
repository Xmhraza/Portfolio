<?php

$dbhost = "localhost";
$dbuser = "root";
$dbpwd = "";
$dbname = "timesheetdb";

$conn = new mysqli($dbhost,$dbuser,$dbpwd,$dbname);

if ($conn -> connect_error){
    die("Connection failed" . $conn->connect_error);
}


?>
<?php

function pwdmatch($pass,$pass2){
    if ($pass == $pass2){
        return true;
    }
    return false;
}
function createUser($conn,$fname,$sname,$email,$pass,$role){
    $sql = "INSERT INTO users (userfirstname, usersurname, useremail, userpwd, usertype) VALUES (?,?,?,?,?);";
    $stmt = mysqli_stmt_init($conn);
    if (!mysqli_stmt_prepare($stmt,$sql)){
        header ("location: ../Account/Create Account.php?error=DBerror");
    }

    $hashpwd = password_hash($pass, PASSWORD_DEFAULT);

    mysqli_stmt_bind_param($stmt,"sssss",$fname,$sname,$email,$hashpwd,$role);
    mysqli_stmt_execute($stmt);
    mysqli_stmt_close($stmt);
    header ("location: ../Account/Create Account.php?error=none");
    exit();
}
function userlogin($conn,$email,$pass,$role){
    $userCred = userExists($conn,$email,$role);
    if ($userCred === false){
        header ("location: ../Login/Index.php?error=invalid");
    }
    $hashedpwd = $userCred["userpwd"];
    $checkpwd = password_verify($pass,$hashedpwd);
    echo $hashedpwd;
    if ($checkpwd === false){
        header ("location: ../Login/Index.php?error=invalid");
        exit();
    }
    else if ($checkpwd == true){
        session_start();
        $_SESSION["Userid"] =  $userCred["userid"];
        $_SESSION["Name"] =  $userCred["userfirstname"] . $userCred["usersurname"];
        $_SESSION["Type"] =  $userCred["usertype"];

    }
    redirector();
}
function userExists($conn,$user, $type){
    $sql = "SELECT * FROM `users` WHERE   `useremail` = ? AND `usertype` = ?;";
    $stmt = mysqli_stmt_init($conn);
    if (!mysqli_stmt_prepare($stmt,$sql)){
        header ("location: ../Account/Create Account.php?error=DBerror");
    }
    mysqli_stmt_bind_param($stmt,"ss",$user,$type);
    mysqli_stmt_execute($stmt);
    $resultData = mysqli_stmt_get_result($stmt);
    if ($row = mysqli_fetch_assoc($resultData)){
        return $row;
    }
    else{
        $result = false;
        return $result;
    }
}
function checkLoggedin(){
    session_start();
    if (isset($_SESSION["Userid"])){
        return true;
    }
    header("location: ../Login/Index.php?error=notloggedin");
}
function checkadmn(){
    if (checkLoggedin() === true){
        if ($_SESSION["Type"] == "Admin"){
            return true;
        }
    }
    redirector();
}
function checkconsul(){
    if (checkLoggedin() === true){
        if ($_SESSION["Type"] == "Consultant"){
            return true;
        }
    }
    redirector();
}
function checkmanag(){
    if (checkLoggedin() === true){
        if ($_SESSION["Type"] == "Manager"){
            return true;
        }
    }
    redirector();
}
function redirector(){
    if ($_SESSION["Type"] == "Admin"){
        header ("location: ../Admin Page/Admin page.php");
    }
    else if ($_SESSION["Type"] == "Consultant"){
        header ("location: ../ConsultantPage/ConsultantPage.php");
    }
    else if ($_SESSION["Type"] == "Manager"){
        header ("location: ../ManagerPage/ManagerPage.php");
    }
}
?>

<header>
    <nav class="navbar">
        <div class="widthm">
            <div class="title">
                <a>FDM Timesheet</a>
            </div>
            <ul class="menu">

                <li><a href="../FAQ/FAQ.php">FAQ</a></li>
                <?php
                session_start();
                if (isset($_SESSION['Userid'])){
                    echo '<li><a href="../Logout/Logout.php">Logout </a></li>';
                }
                else{
                    echo '<li><a href="../Login/">Login </a></li>';
                }
                ?>
                
            </ul>
        </div>
    </nav>
</header> 
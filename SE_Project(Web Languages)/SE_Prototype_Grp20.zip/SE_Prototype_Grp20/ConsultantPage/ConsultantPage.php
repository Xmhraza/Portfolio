<!DOCTYPE html>

<?php
require_once ('../Assets/Setup/functions.php');
checkconsul();
?>
<html>

  <head>
    <link rel="stylesheet" href="timesheetCSS.css">

  </head>

  <body>

    <div class="nav-color">
        <ul>
          <li>
              <a class="account">Consultant</a>
              <a class="dash">Dashboard</a>
              <a  href = "../Logout/Logout.php" class="exit">Exit</a>
          </li>
      </ul>
      </div>
    

      <div class="buttons">

        <div class="grid-container">
          <div class="check" onclick="window.location.href='../Account/Edit Timesheet.html'">
            <button class="raise"></button>
            <a class="label">Edit Timesheet</a>
          </div>
          <div class="check">
            <button class="raise2"></button>
            <a class="label">Submit Timesheet</a>
          </div>
          <div class="check" onclick="window.location.href='../Account/Form.html'">
            <button class="raise3"></button>
            <a class="label">Fill Forms</a>
          </div>
          <div class="check" onclick="window.location.href='../FAQ/FAQ.php'">
            <button class="raise4"></button>
            <a class="label">View FAQs</a>
          </div>
          
        
      </div>
    
      </div>


  </body>



  
</html>
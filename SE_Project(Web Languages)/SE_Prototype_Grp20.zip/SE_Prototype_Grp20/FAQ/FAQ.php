<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>FAQ PAGE</title>
    <link rel="stylesheet" href="FAQstyle.css">
</head>

<body>
    <main>
        <h1 class="heading">FAQ'S</h1>
        <div class = "faq-big">
            <div id="q1">
                <div class="faq-q">How do I edit my timesheet?</div>
                <div class="ans">
                    <p>Sign in to your account with your credentials by the consultant login button. You'll be redirected to the dashboard 
                        in which you'll see an edit timesheet icon. Click on this and make ammendments to your timesheet as necessary.
                    </p>
                </div>
            </div>

            <hr style="width:60%">

            <div id="q2">
                <div class="faq-q">Can I view my timesheet after submission?</div>
                <div class="ans">
                    <p>Yes! Simply navigate to the dashboard and click the review icon. Here you will be able to view previously submitted
                        timesheets
                    </p>
                </div>
            </div>

            <hr style="width:60%">

            <div id="q3">
                <div class="faq-q">Frequenty asked question 3?</div>
                <div class="ans">
                    <p>Lorem ipsum dolor 3</p>
                </div>
            </div>
        </div>
    </main>

    <script>
        
        let numQ = document.getElementsByClassName("faq-q");
        let i;
        for (i = 0; i < numQ.length; i++) {
            numQ[i].addEventListener("click", function () {
                let body = this.nextElementSibling;
                if (body.style.display === "block") {
                    body.style.display = "none";
                } else {
                    body.style.display = "block";
                }
            });
}
    </script>
</body>
</html>
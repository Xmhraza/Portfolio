<?php

if (isset($_POST["submit"])){
    $fname = $_POST["Firstname"];
    $sname = $_POST["Surname"];
    $email = $_POST["Email"];
    $pass = $_POST["Password"];
    $passc = $_POST["Confirm"];
    $role = $_POST["Roles"];

    

    require_once '../Assets/Setup/connect_DB.php';
    require_once '../Assets/Setup/functions.php';
    
    if (userExists($conn,$email,$role) !== false){
        header ("location: ../Account/Create Account.php?error=emailtaken");
        exit();
    }

    if (pwdmatch($pass,$passc) !== true){
        header ("location: ../Account/Create Account.php?error=pwdmatch");
        exit();
    }


    createUser($conn,$fname,$sname,$email,$pass,$role);


}
else{
    header ("location: ../Account/Create Account.php?error=data");
}
?>
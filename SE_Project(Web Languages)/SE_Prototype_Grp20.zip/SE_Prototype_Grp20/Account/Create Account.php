<!-- Author: Jonathan Adekunle -->
<!DOCTYPE html>
<html>
  <head>
    <link rel="stylesheet" href="CEdit.css" />
    <link rel="stylesheet" href="../Assets/Style/Style2.css" />
  </head>

<?php  
include '../Assets/Layout/header.php';  

if (isset($_GET["error"])){
  if ($_GET["error"] == "emailtaken"){
      echo '<script>alert("Email already in use")</script>';

  }
  if ($_GET["error"] == "pwdmatch"){
      echo '<script>alert("Please ensure you type the same password twice")</script>';
  }
  if ($_GET["error"] == "data"){
    echo '<script>alert("ERROR - If continues please contact head")</script>';
}
}

?>


  <body class="RegistrationForm">
    <form  name="RegistrationForm" method="POST" action="CreateAccount.inc.php">
      
    <h1 class="create">CREATE ACCOUNT</h1>

    <div class="row">
    <div class="check">
      <input class="NoDisplay" type="radio" name="Roles" value="Consultant" id="C" checked>
      <input class="NoDisplay" type="radio" name="Roles" value="Manager" id="M">
      <input class="NoDisplay" type="radio" name="Roles" value="Admin" id="A">
      <label class="not-active" type="radio" onclick="removeClasses(this)" for="C" >Consultant</label>
      <label class="not-active" type="radio" onclick="removeClasses(this)" for="M">Manager</label>
      <label class="not-active" type="radio" onclick="removeClasses(this)" for="A">Admin</label>
    </div>
    <br>
    <br>
    <div class="check">
      <input class="margin" id = "Firstname" type="text" name="Firstname" placeholder="Firstname" required><br><br>
      <input class="margin" id = "Surname" type="text" name="Surname" placeholder="Surname" required><br><br>
      <input class="margin" type="email" name="Email" placeholder="Email" required/><br><br>
      <input class="margin" id="pass1"type="password" name="Password" placeholder="Password" pattern="(?=.*\d)(?=.*[A-Z]).{8,}" title="Must contain at least one number and one uppercase letter, and at least 8 or more characters" required/><br><br>
      <input class="margin" id="pass2"type="password" name="Confirm" placeholder="Confirm Password" pattern="(?=.*\d)(?=.*[A-Z]).{8,}" title="Must contain at least one number and one uppercase letter, and at least 8 or more characters" required/><br><br>
    </div>
    </div>

    <input class="sub2" type="submit" value="Submit" name="submit"/>

    </form>
   

    <script>
      const btns = document.querySelectorAll('.not-active');
      console.log(btns.length);
      function removeClasses(target) {
      btns.forEach((btn) => {
      if(btn == target) { 
        btn.classList.add("active"); }
      else { 
        btn.classList.remove("active"); }
  });
}
    </script>


</html>
<?php 

require_once ('../Assets/Setup/functions.php');

checkadmn();
?>
<!DOCTYPE html>
<html>

  <head>
    <link rel="stylesheet" href="timesheetCSS.css">
    <!--
  <div id="dash">
        Dashboard
  </div>
  <div id="account">
    Admin
  </div>

  <div id="top">

    
    </div>
-->
  </head>
  <body>
    <div class="nav-color">
        <ul>
          <li>
              <a class="account">Admin</a>
              <a class="dash">Dashboard</a>
              <a  href = "../Logout/Logout.php" class="exit">Exit</a>
          </li>
      </ul>
    </div>
      <div class="buttons">
        <div class="grid-container">
          <div class="check">
            <button class="raise" onclick="window.location.href='../Account/Create Account.php'"></button>
            <a class="label">Create Account</a>
          </div>
          <div class="check">
            <button class="raise2" onclick="window.location.href='../Account/Delete Account.html'"></button>
            <a class="label">Delete Account</a>
          </div>
          <div class="check">
            <button class="raise3"></button>
            <a class="label">View Forms</a>
          </div>
          <div class="check" onclick="window.location.href='../FAQ/FAQ.php'">
            <button class="raise4"></button>
            <a class="label">View FAQs</a>
          </div>
      </div>
    </div>


  </body>



  
</html>
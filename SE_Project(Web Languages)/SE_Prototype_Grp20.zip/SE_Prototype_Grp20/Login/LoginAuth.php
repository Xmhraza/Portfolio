<?php

if (isset($_POST["login-btn"])){
    $email = $_POST["user"];
    $pass = $_POST["pass"];
    $role = $_POST["Roles"];

    

    

    require_once '../Assets/Setup/connect_DB.php';
    require_once '../Assets/Setup/functions.php';



    userlogin($conn,$email,$pass,$role);
    

}
else{
    echo 'error';
}
?>
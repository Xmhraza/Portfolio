<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login</title>
    <link rel="stylesheet" href='../Assets/Style/Style2.css'>
    <link rel="stylesheet" href='../Assets/Style/LoginCheck.css'>
</head>
<?php 
include '../Assets/Layout/header.php'; 
require_once ('../Assets/Setup/functions.php');
session_start();
if (isset($_SESSION["Userid"])){
    redirector();
}


if (isset($_GET["error"])){
    if ($_GET["error"] == "invalid"){
        echo '<script>alert("Invalid login details")</script>';

    }
    if ($_GET["error"] == "notloggedin"){
        echo '<script>alert("Please log in to perform actions")</script>';
    }
}


?>
<body>

    <div class="Login-div">
        <form class ="login" action="LoginAuth.php" method="POST">
            <h1>Login</h1>
            <div class="breaker"></div>
            <div class="selector">
                <input type="radio" name="Roles" value="Consultant" id="C" checked>
                <input type="radio" name="Roles" value="Manager" id="M">
                <input type="radio" name="Roles" value="Admin" id="A">
                <label class="butn" for="C" >Consultant</label>
                <label class="butn" for="M">Manager</label>
                <label class="butn" for="A">Admin</label>
            </div>
            <div class="breaker"></div>
            <h2>Credentials</h2>
            <div class="email">
                <input type="text" name="user" placeholder="  Email Address" required>
            </div>
            <div class="pass">
                <input type="password" name="pass" placeholder="  Password" required>
            </div>
            <div class="LastSection">
                <input class="loginBtn" type="submit" name="login-btn">
            </div>
            
        </form>
    </div>
    
    
</body>
<?php 
include '../Assets/Layout/footer.php'; 
?>
</html>
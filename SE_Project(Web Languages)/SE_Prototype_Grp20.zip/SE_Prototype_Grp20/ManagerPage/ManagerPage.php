<!DOCTYPE html>
<?php

require_once ('../Assets/Setup/functions.php');
checkmanag();
?>
<html>

  <head>
    <link rel="stylesheet" href="timesheetCSS.css">
    <!--
  <div id="dash">
        Dashboard
  </div>
  <div id="account">
    Admin
  </div>

  <div id="top">

    
    </div>

    <div class="check">
            <button class="raise3"></button>
            Use Forms
          </div>
          <div class="check">
            <button class="raise4"></button>
            View Notes
          </div>
          <div class="check">
            <button class="raise5"></button>
            Submit Timesheet
          </div>
          <div class="check">
            <button class="raise6"></button>
            Review
          </div>
-->
  </head>

  <body>

    <div class="nav-color">
        <ul>
          <li>
              <a class="account">Manager</a>
              <a class="dash">Dashboard</a>
              <a href = "../Logout/Logout.php" class="exit">Exit</a>
          </li>
      </ul>
      </div>
    

      <div class="buttons">

        <div class="grid-container">
          <div class="check">
            <button class="raise" onclick="window.location.href='../Account/Assess Timesheet.html'"></button>
            <a class="label">Assess Timesheet</a>
          </div>
          <div class="check">
            <button class="raise2"></button>
            <a class="label">View Archived Timesheets</a>
          </div>
          <div class="check">
            <button class="raise3"></button>
            <a class="label">View Forms</a>
          </div>
          <div class="check" onclick="window.location.href='../FAQ/FAQ.php'">
            <button class="raise4"></button>
            <a class="label">View FAQs</a>
          </div>
          
        
      </div>
    
      </div>


  </body>



  
</html>
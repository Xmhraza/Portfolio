<header>
    <nav class="navbar">
        <div class="widthm">
            <div class="title">
                <a>FDM Timesheet</a>
            </div>
            <ul class="menu">
                <li><a href = "../Homepage">Home</a></li>
                <li><a href="../Contact/">Contact Us</a></li>
                <?php
                session_start();
                if (isset($_SESSION['auth'])){
                    echo '<li><a href="../Contact/">Logout </a></li>';
                }
                else{
                    echo '<li><a href="../Login/">Login </a></li>';
                }
                ?>
                
            </ul>
        </div>
    </nav>
</header> 
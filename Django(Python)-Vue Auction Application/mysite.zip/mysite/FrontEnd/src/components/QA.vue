<script lang="ts">

import { defineComponent } from 'vue'


 export default defineComponent({
  data() {
    return {
      Item: 
       {
        id: Int32Array,
        name: String,
        category: String,
        owner: String,
        startPrice: Int32Array,
        startDate: Date,
        endtdate: Date,
        description: String,
        availability: Boolean
      },
      QA: [
       {
        id: Int32Array,
        questionto: String,
        sender: String,
        itemname: String,
        Question: String,
        Answer: String,
      }],
        SendQuestion: {
          ownername: String,
          itemid: Int32Array,
          Question: String("")
        },
        Add: {
          TempId: Int32Array,
          AddToPrice: new Int32Array,
        },
        HighestBidder: new Boolean
        
    }
    }, methods: {
        async fetchItem() {
      let response = await fetch(`http://localhost:8000/Questions/${this.$route.params.id}`, {
        credentials: 'include',
        mode: 'cors',
        referrerPolicy: "no-referrer",
      })
      //console.log(response)
      let data = await response.json()
      this.QA = data.QA
      this.Item = data.item
      this.HighestBidder = data.Bidder
      console.log(this.Item)
      //this.Messages = finaldata
      //this.Messages = data.Testing
    },
    async AddTestData() {
      this.SendQuestion.ownername = this.Item.owner;
      this.SendQuestion.itemid = this.Item.id;
      let response = await fetch("http://localhost:8000/QAPost/", {
        method: "POST",
        credentials: 'include',
        mode: 'cors',
        headers: {
          'Content-Type': 'application/json'
      },
       body: JSON.stringify(this.SendQuestion),
      })
      console.log(response)
      let data = await response
      this.fetchItem()
      
      //this.Messages = data.Testing
    },async AddToValue() {
      this.Add.TempId = this.Item.id
      let response = await fetch("http://localhost:8000/Addition/", {
        method: "PUT",
        credentials: 'include',
        mode: 'cors',
        headers: {
          'Content-Type': 'application/json'
      },
       body: JSON.stringify(this.Add),
      })
      console.log(response)
      let data = await response
      this.fetchItem()
      
      //this.Messages = data.Testing
    }

    },beforeMount() {
      this.fetchItem()
  }
 })

 </script>

 <template>
    <div class="col-md-3 firstColumn h-20">
      <div  v-if="Item.name != null">
        <h2> 
        <!-- ignore if there are any error lines for item description. They will still work properly-->
         Name: {{ Item.name }}  
        </h2>
        <h4>Description: {{ Item.description }} </h4>
        <div>
          Current Price: {{ Item.startPrice }} dollars

          <label class="row">Bid (Add) : <input v-model="Add.AddToPrice" placeholder="edit me"/></label>
          <button @click="AddToValue()"> Confirm bid</button> 
        </div>
        <div v-if="HighestBidder==true">
          You are the highest bidder
        </div>
      </div>
        
      

        <!-- Every commented lines are optional features or lines for testing so please ignore-->
        <!--<label class="row">Enter ID : <input v-model="SpecificId" type="number"/></label> -->
        <br>
        <br>
        
        <!--<button @click="fetchItem()"> Refresh page </button>-->
        <br><br>
            <p v-for="message in QA">
            <!--ID: {{ message.id }} <br>-->
            <h3>Sender: {{ message.sender }} </h3> <br>
            <div>
            Question: {{ message.Question }} <br>
            Answer: {{ message.Answer }}
          </div>
            
            </p>
        <!--{{secondtest}}-->
      </div>

      <div v-if="Item.name != null" class="col-md-3 secondColumn h-20">
        <h2> Ask Question </h2>
        <label class="row">Enter Question For Item : <input v-model="SendQuestion.Question" placeholder="edit me"/></label>

       
        <button @click="AddTestData"> Submit</button> 
        <br><br>
      </div>
 </template>


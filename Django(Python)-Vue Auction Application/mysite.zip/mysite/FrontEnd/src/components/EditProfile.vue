<script lang="ts">

import { defineComponent } from 'vue'


export default defineComponent({
  data() {
    return {
        Profile: [

        ],
        UpdateProfile:{
            email: null,
            city: null,
            dateofbirth: null,
        }
    }
    }, 
    methods:{
        async saveNew() {
            let response = await fetch("http://localhost:8000/profile/", {
                method: "POST",
                credentials: 'include',
                mode: 'cors',
                referrerPolicy: "no-referrer",
                body: JSON.stringify({
                    email : this.UpdateProfile.email,
                    city : this.UpdateProfile.city,
                    dateofbirth : this.UpdateProfile.dateofbirth,
                }),
            });
            let data =  await response.json();
            console.log(response); 

            this.$router.replace('/')

        },

}
})
</script>
<template>
    <div class="main">
        <h1 class="title"> Update Profile </h1>
        <label class="formlabel"> Image: </label>
        <br/>

        <label class="formlabel"> Email: </label>
        <input type="email" v-model="UpdateProfile.email" placeholder="Enter your email" class="form-control"/>
        <br/>

        <label class="formlabel"> City: </label>
        <input type="text" v-model="UpdateProfile.city" placeholder="Enter city name" class="form-control"/>
        <br/>

        <label class="formlabel"> Date of Birth: </label>
        <input type="date" v-model="UpdateProfile.dateofbirth" class="form-control"/>
        <br/>

        <button id="savebutton"  type="button" @click="saveNew"> Save </button>
    </div>
</template>

<style>
    .main{
        border: solid black;
        margin-top: 1em;
    }
    .title{
        color: black;
        padding: 1em;
        text-decoration: underline;
    }
    .formlabel{
        color: black;
        margin: 1em;
        margin-right: 0.5em;
        padding: 1em;
    }
    .form-control{
        border: solid black;
        margin: 1em;
        padding: 0.5em;
    }
    #savebutton{
        color: black;
        background-color: white;
        border: solid black;
        padding: 1em;
        margin: 1em;
    }
</style>
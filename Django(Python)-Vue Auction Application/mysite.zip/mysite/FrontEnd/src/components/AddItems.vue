<template>
        <div class="body">
  
          <div class="first">
            <label for="name" class="formlabel">Item Name:  </label>
            <input required class="form-control" name="name" v-model="name">
        </div>
        <br/>
        <div class="second">
            <label for="category" class="formlabel">Category:  </label>
            <input required class="form-control" name="category" v-model="category">
        </div>
        <br/>
       <div class="third">
            <label for="category" class="formlabel">Description:  </label>
            <input required class="form-control" name="category" v-model="description">
        </div>
        <br/>
        <div class="fourth">
            <label for="startPrice" class="formlabel">Starting Price:  </label>
            <input required type="number" class="form-control" name="startPrice" v-model="startPrice">
        </div>
        <br/>
        <div class="fifth">
            <label for="endDate" class="formlabel">End Date:  </label>
            <input required type="date" class="form-control" name="endDate" v-model="endDate">
        </div>
        <br/>

        <button id="addbutton" @click="add_Item(name, category,description, startPrice, endDate)"> Add Item </button>
          <br><br>
  
      </div>
  
  </template>

<style>
.body{
    background-color: white;
    padding: 1em;
    border: solid black;
    margin-top: 1em;
}
.first{
    padding-bottom: 0.5em;
}
.second{
    padding-bottom: 0.5em;
}
.third{
    padding-bottom: 0.5em;
}
.fourth{
    padding-bottom: 0.5em;
}
.formlabel{
    margin-left: 1em;
    margin-bottom: 1em;
    margin-top: 1em;
    color: black;
}
.form-control{
    border: solid black;
}
#addbutton{
    color: black;
    background-color: white;
    border: solid black;
    margin: 1em;
}
</style>
  
  <script lang='ts'>
  import Vue from 'vue';
  
  export default{
    data() {
      return {
        name : String (""),
        category: String(""),
        description:String(""),
        startPrice:new Int32Array,
        endDate:new Date,
  
      };
    },
  
    methods: {
  
      async add_Item(name: String, category: String, description: String, startPrice: Int32Array, endDate:Date){
        const object = { name, category,description,startPrice,endDate};
        const response = await fetch('http://localhost:8000/Item/', {
          method: 'POST',
          credentials: 'include',
          mode: 'cors',
          headers: {
          'Content-Type': 'application/json'
          },
          body: JSON.stringify(object)
        });
        
        this.$router.replace('/Listing')
        }
  
    },
  };
  </script>
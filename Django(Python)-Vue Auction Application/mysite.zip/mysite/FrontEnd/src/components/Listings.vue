<template>
    <div>
  
  
      <h1 class="heading">My Items</h1>
      <label class="formlabel">Search for : <input class="row" type='text' v-model="search"></label>
      <div v-for="item in filteredItems">
            <h3><router-link :to="`/QA/${item.id}`">{{item.name}}</router-link></h3>
           Category: {{item.category}} |  Current Price: {{item.startPrice}} | End Date: {{item.endDate}} | <!--<button @click="deleteReview(item.id)" class="btn btn-danger p-2">Delete Item</button>-->
          <!--v-bind:id="item.id"-->
          <br>
          <br>
          <br>
        </div>
   
      </div>
      <br>
  </template>

<style>
.heading{
  color: black;
  text-decoration: underline;
  margin: 1em;
}
.row{
  border: solid black;
  padding: 0.25em;
  margin: 1em;
}
</style>
  
  <script lang='ts'>
  
  import Vue from 'vue';
  
  export default{
    data() {
      return {
        items: [{
          id: new Int32Array,
          name: String,
          owner: String,
          category: String,
          description: String,
          startPrice: Number,
          endDate: Date,
          availability: Boolean,
          highestbidder: String
        }
        ],
        name : String (""),
        category: String(""),
        description:String(""),
        startPrice:Number,
        endDate:Date,
        search: String("")
  
      };
    },
    async mounted() {
      let response = await fetch("http://localhost:8000/Item/", {
          credentials: 'include',
           mode: 'cors',
        });
      let data = await response.json();
      this.items = data.items;
      console.log(this.items);

      let response1 = await fetch("http://localhost:8000/SendMail/");
    },
    methods: {
      async fetchItems(){
        let response = await fetch("http://localhost:8000/Item/", {
          credentials: 'include',
           mode: 'cors',
        });
        let data = await response.json();
        this.items = data.items;
        console.log(this.items);
      },
  
      async deleteReview(id: Int32Array) {
        let response = await fetch(`http://localhost:8000/delete/${id}/`, {
            method: 'DELETE',
            credentials: 'include',
            mode: 'cors',
            referrerPolicy: "no-referrer",
        },
        );
        this.fetchItems();
      },
  
  
    },
    computed: {
    filteredItems(){
      return this.items.filter(item => item.category.toString().toLowerCase().includes(this.search.toLowerCase()));
    }
   }
};

  </script>
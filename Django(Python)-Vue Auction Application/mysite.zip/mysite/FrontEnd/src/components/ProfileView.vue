<script lang="ts">
export default {
    data(){
        return{
            Profile : {
                Image: String(""),
                email: String(""),
                city: String(""),
                dateofbirth: Date,
                
            },

            Available: new Boolean

            
        }
    },
    methods:{
        async fetchProfile(){
            let response = await fetch("http://localhost:8000/profile/", {
                credentials: 'include',
                mode: 'cors',
                referrerPolicy: "no-referrer",
            });
            let data = await response.json()
            this.Profile = data.profile
            this.Available = data.available
       }
    },beforeMount() {
      this.fetchProfile()
  }
}
</script>

<template>

    <div v-if="Available==true" class="list">
         Email: {{Profile.email }} <br>
         City: {{ Profile.city }} <br>
         DoB: {{ Profile.dateofbirth }}
    </div>
    <div v-if="Available==false" class="statement">
       No data provided for the profile. Please edit!
    </div>
 
    <router-link to="/Profile" class="editbutton">Edit Profile</router-link>
    <br><br>
 
 </template>
 
 <style>
     .editbutton{
         border: solid black;
         border-radius: 25px;
         padding: 1em;
         margin: 1em;
     }
     .list{
         color: black;
         margin: 1em;
         margin-bottom: 2em;
         padding: 1em;
     }
     .statement{
         color: black;
         margin: 1em;
         margin-bottom: 2em;
     }
 </style>
 
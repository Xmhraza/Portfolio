<script lang="ts">

import { defineComponent } from 'vue'



 export default defineComponent({
  data() {
    return {
      QA: [
       {
        id: Int32Array,
        questionto: String,
        sender: String,
        item: String,
        Question: String,
        Answer: String,
      }],
        SendMessage: {
        id: new Int8Array,
        Answer: String(""),
      },
        data: [],
        newvalue: [],
       
    }
    }, methods: {
        async fetchQuestionAsked() {
      let response = await fetch("http://localhost:8000/Answer/", {
        credentials: 'include',
        mode: 'cors',
        referrerPolicy: "no-referrer",
      })
      //console.log(response)
      let data = await response.json()
      this.QA = data.AllQuestions
      console.log(this.QA)
      //this.Messages = finaldata
      //this.Messages = data.Testing
    },
    async AddAnswer() {
      let response = await fetch("http://localhost:8000/Answer/", {
        method: "PUT",
        credentials: 'include',
        mode: 'cors',
        headers: {
          'Content-Type': 'application/json'
      },
       body: JSON.stringify(this.SendMessage),
      })
      console.log(response)
      let data = await response
      this.fetchQuestionAsked()
      
      //this.Messages = data.Testing
    }
    },beforeMount() {
      this.fetchQuestionAsked()
  }
 })

 </script>

<template>
  <div class="col-md-3 firstColumn h-20">
      <h2 class="heading"> Questions sent to you </h2>

      <p v-if="QA.length == 0">
         You have no questions available
      </p>
      <!-- Every commented lines are optional features or lines for testing so please ignore-->
      <!--<label class="row">Enter ID : <input v-model="SpecificId" type="number"/></label> -->
      <br>
      <br>
        <p v-for="message in QA">
          ID: {{ message.id }} <br>
          User: {{ message.sender }} <br>
          Item Name: {{ message.item }} <br>
          Question: {{ message.Question }}<br> 
        </p>
      <!--{{secondtest}}-->
    </div>

    <div class="col-md-3 secondColumn h-20">
      <h2 class="heading"> Answer Question by ID </h2>
      <label class="formlabel">Enter Question ID : <input v-model="SendMessage.id" placeholder="edit me" class="row"/></label>
      <br/>
      <label class="formlabel">Enter Answer : <input v-model="SendMessage.Answer"  type="text" class="row"/> </label>

      <br>
      <button class="submitbutton" @click="AddAnswer"> Submit</button> 
    </div>
</template>

<style>
.heading{
  color: black;
}
.submitbutton{
  color: black;
  border: solid black;
  background-color: white;
  padding: 0.5em;
  margin: 1em;
}
.row{
  border: solid black;
  padding: 0.5em;
  margin: 1em;
}
</style>

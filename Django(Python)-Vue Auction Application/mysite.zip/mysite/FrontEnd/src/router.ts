import { createRouter, createWebHistory } from 'vue-router'
import HelloWorld from './components/HelloWorld.vue'

export default createRouter({
    history: createWebHistory(),
    routes: [
      {
        path: '/QA',
        component: () => import('./components/QA.vue'),
      },
      {
        path: '/QA/:id',
        component: () => import('./components/QA.vue'),
      },
      {
        path: '/Answer',
        component: () => import('./components/AnsRequired.vue'),
      },
      {
        path: '/AddItem',
        component: () => import('./components/AddItems.vue'),
      },
      {
        path: '/Listing',
        component: () => import('./components/Listings.vue'),
      },
      {
        path: '/Profile',
        component: () => import('./components/EditProfile.vue'),
      },
      {
        path: '/',
        component: () => import('./components/ProfileView.vue'),
      }
    ],
  })
<script lang="ts">
import { createRouter, createWebHistory } from 'vue-router'
import HelloWorld from './components/HelloWorld.vue'



 export default {
   components: {
   },
    data() {
       return {
         currentPath: window.location.hash,
         id: ""
          
       }
    }, methods: {
      async logout() {
      let response = await fetch("http://localhost:8000/logout", {
        credentials: 'include',
        mode: 'cors',
        referrerPolicy: "no-referrer",
      })
      //console.log(response)
      //let data = await response.json()
      //this.Messages = finaldata
      //this.Messages = data.Testing
    },
    },
 }

 </script>

 <template>
  <nav class="nav-bar">
   <router-link to="/">Profile</router-link> |  <router-link to="/Answer">Answer</router-link> |  <router-link to="/AddItem">Add Item</router-link> | <router-link to="/Listing">Auction List</router-link> 
  </nav>
  <main>
    <router-view />

    <button @click="logout()"> logout</button> 

  </main>

 </template>

<style>
.nav-bar{
  background-color: white;
  border: solid black;
  padding: 0.5em;
  margin: 1em;
}
.router-link{
  color: black;
}
</style>

from django.db import models
from django.contrib.auth.models import AbstractUser
from django.utils import timezone

# Create your models here.
class User(AbstractUser):
    username = models.CharField(max_length=10, unique=True)
    messages = models.ManyToManyField(
        to='self',
        blank=True,
        through='Message',
    )
    profile = models.OneToOneField(
        to='Profile',
        blank=True,
        null=True,
        on_delete=models.CASCADE
    )

    def __str__(self):
        return self.username

    def to_dict(self):
        return {
            'username': self.username,
            'messages': [message.to_dict() for message in self.messages]
        }
    
    @property
    def GetMessages(self):
        MR = Message.objects.filter(recip=self)
        MS = Message.objects.filter(sender=self)
        return MR.union(MS).order_by('-time')
    

class Message(models.Model):
    '''
    The Message models is the 'through' model for
    the 'message' ManyToMany relationship between Members
    '''
    sender = models.ForeignKey(
        to=User,
        related_name='sent',
        on_delete=models.CASCADE
    )
    recip = models.ForeignKey(
        to=User,
        related_name='received',
        on_delete=models.CASCADE
    )
    text = models.CharField(max_length=4096)
    time = models.DateTimeField(default=timezone.now)

    def __str__(self):
        return f"From {self.sender} to {self.recip}"

    def to_dict(self):
        return {
            'sender': self.sender.username,
            'recip': self.recip.username,
            'text': self.text,
            'time': self.time.strftime("%Y-%d-%mT%H:%M"),
        }

class Profile(models.Model):

    image = models.ImageField(default= 'WebProgrammingCW/profile-image.png', upload_to='Images')
    email = models.EmailField(max_length=200)
    city = models.CharField(max_length=200) 
    dateofbirth = models.DateField(default=timezone.now())
    
    belongsto = models.ForeignKey(
        to=User,
        related_name='belongsto',
        on_delete=models.CASCADE
    )

    def to_dict(self):
        return {
            'image':self.image.url ,
            'email': self.email,
            'city': self.city,
            'dateofbirth': self.dateofbirth
        }


class Items(models.Model):
    #owner field needs foriegn keyexit
    id = models.AutoField(primary_key=True)
    name = models.CharField(max_length=350)
    description = models.CharField(max_length=350, default="no description provided")
    category = models.CharField(max_length=350)
    owner = models.ForeignKey(
        to=User,
        related_name='owner',
        on_delete=models.CASCADE
    )
    startPrice = models.IntegerField()
    endDate = models.DateField()
    availability = models.BooleanField(default=True)
    highestbidder = models.ForeignKey(
        to=User,
        related_name='highestbidder',
        on_delete=models.CASCADE,
        blank=True
    )


    def __str__(self) -> str:
        """returns the name of the object when the object is called"""
        return self.name


    def to_dict(self):
         """returns the object in the form of a dictionary"""
         return {
             "id" : self.id,
             "name" : self.name,
             "category": self.category,
             "description": self.description,
             "owner" : self.owner.username,
             "startPrice" : self.startPrice,
             "endDate" : self.endDate,
             "availability" : self.availability,
        }
    
    @property
    def GetQA(self):
        MR = QuestionAndAnswer.objects.filter(Item=self)
        return MR

    
class QuestionAndAnswer(models.Model):
    '''
    The Message models is the 'through' model for
    the 'message' ManyToMany relationship between Members
    '''
    id = models.AutoField(primary_key=True)
    questionto = models.ForeignKey(
        to=User,
        related_name='questionto',
        on_delete=models.CASCADE
    )
    sender = models.ForeignKey(
        to=User,
        related_name='sender',
        on_delete=models.CASCADE
    )
    Item = models.ForeignKey(
        to=Items,
        related_name='item',
        on_delete=models.CASCADE
    )
    Question = models.CharField(max_length=4096)
    Answer = models.CharField(max_length=4096, default="")

    #def __str__(self):
        #return f"From {self.sender} to {self.recip}"

    def to_dict(self):
        return {
            'id': self.id,
            'owner': self.questionto.username,
            'sender': self.sender.username,
            'item': self.Item.name,
            'Question': self.Question,
            'Answer': self.Answer,
        }

    



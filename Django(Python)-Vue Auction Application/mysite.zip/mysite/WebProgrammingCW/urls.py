from django.urls import path

from .models import User

from WebProgrammingCW import views

urlpatterns = [
    path("signup/", views.signup_view, name="signup"),
    path('login/', views.login_view, name='login'),
    path('logout/', views.logout_view, name='logout'),
    path('QAPost/', views.QAPost),
    path('Questions/<int:Value>/', views.QA),
    path('Addition/', views.Addition),
    path('delete/<int:Value>/', views.delete_event),
    path('Answer/', views.Answer),
    path('SendMail/', views.SendMail),
    path('Item/', views.Item),
    path('profile/', views.profile),
]
from django.shortcuts import render
from django.shortcuts import get_object_or_404, render, redirect
from django.contrib.auth.decorators import login_required
from django.http import HttpRequest, HttpResponse, JsonResponse
from .models import User, Message, Items, QuestionAndAnswer, Profile
from django.contrib import auth
from .forms import SignupForm, LoginForm
import json
from django.utils import timezone
from django.core.mail import send_mail
import urllib

def signup_view(request):
    '''
    Signup function
    Users creating an account
    '''

    form = SignupForm()

    if request.method == 'POST':
        form = SignupForm(request.POST)
        if form.is_valid():
            username = form.cleaned_data['username']
            password = form.cleaned_data['password']
            new_user = User.objects.create(username=username)
            new_user.set_password(password)
            new_user.save()
            user = auth.authenticate(username=username, password=password)
            if user is not None:
                auth.login(request, user)
                return render(request, 'WebProgrammingCW/login.html', {'form': LoginForm})

    return render(request, 'WebProgrammingCW/signup.html', {'form': SignupForm})

def login_view(request):
    '''
    Login function
    Users logging into the app
    '''

    form = LoginForm()

    if request.method == 'POST':
        form = LoginForm(request.POST)
        if form.is_valid():
            username = form.cleaned_data['username']
            password = form.cleaned_data['password']
            user = auth.authenticate(username=username, password=password)
            if user is not None:
                auth.login(request, user)
                return render(request, 'WebProgrammingCW/login.html', {'form': form}) #redirect('login')

            '''return render(request, 'error.html', {
                'error': 'User not registered. Sign up first.'
            })'''

        return render(request, 'WebProgrammingCW/login.html', {
            'form': form
        })

    return render(request, 'WebProgrammingCW/login.html', {'form': form})

@login_required
def logout_view(request):
    auth.logout(request)
    return HttpResponse({
            'Testing': "it worked"
            
        })

def QA(request, Value: int):
    '''Used to send an item to the dynamic item page'''
    if request.user.is_authenticated:
        print(request.user)
        item = Items.objects.get(id=Value)
        user = request.user
        if item.highestbidder == request.user:
            Bidder = True
        else:
            Bidder = False
        if request.method == 'GET':
            #check = get_object_or_404(User, username=user.username)
            AllQA = item.GetQA
            return JsonResponse({
                'QA': [
                    QA.to_dict() for QA in AllQA
                ], 'item': item.to_dict(),
                'Bidder': Bidder
            })

def QAPost(request):
    '''used to ask a question in the dynamic item page'''
    if request.user.is_authenticated:
        if request.method == 'POST':
            data = json.loads((request.body))
            sender = request.user
            itemid = data.get('itemid')
            item = Items.objects.get(id=itemid)
            owner = User.objects.get(username=data.get('ownername'))
            Question = data.get('Question')
            #newmessage = Message(sender=user, recip=recipient, text=text1)
            #newmessage.save()
            Question = QuestionAndAnswer.objects.create(
                questionto=owner,
                sender=sender,
                Question=Question,
                Item=item,
            ) 
            Question.save()
            return JsonResponse({
                'Testing': "it worked"
            
            })
        
    
def Answer(request):
    '''used to answer a question in the answer page of the user'''
    if request.user.is_authenticated:
        if request.method == 'GET':
            print("check")
            owner = request.user
            QA = QuestionAndAnswer.objects.filter(questionto=owner, Answer="")
            return JsonResponse({
                'AllQuestions': [
                    item.to_dict() for item in QA
                ],
            })
        if request.method == 'PUT':
            data = json.loads((request.body))
            question = get_object_or_404(QuestionAndAnswer, id=data.get('id'))
            if data.get('Answer') != None:
                question.Answer = data.get('Answer')
            question.save()
            return JsonResponse({
                'Testing': "it worked"
            
            })

    

def Item(request):
    '''used to get all items for the listing page and post an item to the listing page'''
    if request.user.is_authenticated:
        if request.method == "GET":
            return JsonResponse({
                'items' : [
                    item.to_dict()
                    for item in Items.objects.filter(availability=True, endDate__gte=timezone.now())
                ]
            })
        if request.method == 'POST':
            data = json.loads((request.body))
            item = Items.objects.create(name=data.get('name'), owner=request.user, startPrice=data.get('startPrice'), 
            endDate=data.get('endDate'), description=data.get('description'), availability=True, category=data.get('category'), highestbidder=request.user)
            item.save()
            return JsonResponse({
                'Testing': "it worked"
            
            })
    else:
        return JsonResponse({
                'Error': "Not Authenticated"
            
            })
    

def delete_event(request: HttpRequest, Value: int) -> HttpResponse:
    """method used to perform delete request. NOT USED"""
    item = Items.objects.get(id=Value)
    if request.method == 'DELETE':
        """checks to see if reqeust is delete"""
        item.delete()
    return HttpResponse("Deleted")

def Addition(request: HttpRequest) -> HttpResponse:
    """method used to perform add a price to the current bid"""
    if request.user.is_authenticated:
        if request.method == 'PUT':
            data = json.loads((request.body))
            item = Items.objects.get(id=data.get('TempId'))
            item.startPrice += int(data.get('AddToPrice'))
            item.highestbidder = request.user
            item.save() 
        """checks to see if reqeust is delete"""
        return HttpResponse("New Price Added")    

def profile(request):
    '''used to show the profile on the profile page and edit any parts except the image which is not included'''
    if request.user.is_authenticated:
        user = request.user
        if request.method == 'GET':
            if user.profile:
                profAvailable = True
            else:
                profAvailable = False

            return JsonResponse({
            'profile': user.profile.to_dict() , 
            'available': profAvailable
            })

        if request.method == 'POST':
            data = json.loads((request.body))
            if user.profile:
                if data.get('dateofbirth') != None:
                    user.profile.dateofbirth = data.get('dateofbirth')
                if data.get('email') != None:
                    user.profile.email = data.get('email')
                if data.get('city') != None:
                    user.profile.city = data.get('city')

                user.profile.save()
            else:
                if data.get('dateofbirth') != None:
                    dateofbirth = data.get('dateofbirth')
                else:
                    dateofbirth = timezone.now()
                if data.get('email') != None:
                    email = data.get('email')
                else:
                    email = 'No email provided'
                if data.get('city') != None:
                    city = data.get('city')
                else:
                    city = 'No city provided'

                profile = Profile(belongsto=request.user, dateofbirth = dateofbirth, email = email, city = city, image='Images/profile-image.png')
                profile.save()
                user.profile = profile

            user.save()

            return JsonResponse({
                'Testing': "it worked"
            })

def SendMail(request):
    '''send mail function.'''
    items = Items.objects.filter(endDate=timezone.now(), availability=True)
    for item in items:
        if (item.highestbidder.profile.email != None):
            print(item.highestbidder.profile.email)
        send_mail(
            'Subject here' + item.name,
            'Here is the message.',
            'hamidricky44@gmail.com',
            [item.highestbidder.profile.email],
            fail_silently=False,
        )  
        item.availability = False
        item.save()

    print("Hello")
    
    return HttpResponse("EmailSent")


# Create your views here.

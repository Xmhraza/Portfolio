from django.core.mail import send_mail


def my_cron_job():
    print("Hello")
    send_mail(
    'Subject here',
    'Here is the message.',
    'hamidricky44@gmail.com',
    ['abraznino44@gmail.com'],
    fail_silently=False,
)
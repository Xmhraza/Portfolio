from django.contrib import admin
from django.contrib.auth.admin import UserAdmin
from .models import User, Message, Items, QuestionAndAnswer, Profile

class TodoListAdmin(admin.ModelAdmin):
    readonly_fields = ('id',)

admin.site.register(User)
admin.site.register(Message)
admin.site.register(Items, TodoListAdmin)
admin.site.register(QuestionAndAnswer)
admin.site.register(Profile)

# Register your models here.
